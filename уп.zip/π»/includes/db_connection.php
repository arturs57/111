<?php
// Подключение к базе данных
$db_host = 'localhost'; // Адрес сервера базы данных
$db_user = 'root'; // Пользователь базы данных
$db_password = ''; // Пароль пользователя базы данных
$db_name = 'practic'; // Имя базы данных

$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name);

// Проверка соединения
if (!$conn) {
    die("Ошибка подключения: " . mysqli_connect_error());
}
?>
