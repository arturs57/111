<?php
include_once('../../includes/auth_functions.php');

// Проверяем, авторизован ли пользователь и имеет ли он права администратора
if (!is_logged_in() || get_user_role($_SESSION['username']) != 'admin') {
    header("Location: ../../pages/login.php"); // Перенаправляем на страницу входа
    exit();
}

// Здесь выводится список заказов для управления администратором
?>
