<?php
include_once('../includes/auth_functions.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (login_user($username, $password)) {
        // Успешный вход в систему
        header("Location: index.php"); // Перенаправление на главную страницу после входа
        exit();
    } else {
        // Ошибка входа
        $login_error = "Неверное имя пользователя или пароль.";
    }
}
?>

<!-- Форма входа -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <input type="text" name="username" placeholder="Имя пользователя" required><br>
    <input type="password" name="password" placeholder="Пароль" required><br>
    <button type="submit">Войти</button>
</form>

<?php
if(isset($login_error)) {
    echo "<p>$login_error</p>";
}
?>
