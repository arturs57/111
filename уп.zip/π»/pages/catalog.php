<!DOCTYPE html>
<html lang="<ru></ru>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ваш заголовок сайта</title>
    <link rel="stylesheet" href="уп/css/style.css">
</head>
<body>
    <header>
        <!-- Здесь может быть ваша навигационная панель или другие элементы заголовка -->
        <?php include_once('../includes/navigation.php');?>
    </header><?php include_once('../includes/header.php'); ?>

<main>
 
    <section>
        <h2>Регистрация и авторизация</h2>
        <p>Для оформления заказа, пожалуйста, зарегистрируйтесь или войдите в систему.</p>
        <a href="../pages/registration.php"><button>Регистрация</button></a>
        <a href="../pages/login.php"><button>Авторизация</button></a>
    </section>
</main>

<?php include_once('../includes/footer.php'); ?>
</body>