<?php
include_once('../includes/auth_functions.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    if (register_user($username, $password, $role)) {
        // Успешная регистрация
        header("Location: login.php"); // Перенаправление на страницу входа после регистрации
        exit();
    } else {
        // Ошибка регистрации
        $registration_error = "Ошибка при регистрации пользователя.";
    }
}
?>

<!-- Форма регистрации -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <input type="text" name="username" placeholder="Имя пользователя" required><br>
    <input type="password" name="password" placeholder="Пароль" required><br>
    <select name="role">
        <option value="admin">Администратор</option>
        <option value="client">Клиент</option>
        <option value="editor">Редактор</option>
    </select><br>
    <button type="submit">Зарегистрироваться</button>
</form>

<?php
if(isset($registration_error)) {
    echo "<p>$registration_error</p>";
}
?>
